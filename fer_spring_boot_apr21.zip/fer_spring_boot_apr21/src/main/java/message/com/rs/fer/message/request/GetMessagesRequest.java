package com.rs.fer.message.request;

public class GetMessagesRequest {

	private int messageTheradId;
	private int userdId;

	public int getMessageTheradId() {
		return messageTheradId;
	}

	public void setMessageTheradId(int messageTheradId) {
		this.messageTheradId = messageTheradId;
	}

	public int getUserdId() {
		return userdId;
	}

	public void setUserdId(int userdId) {
		this.userdId = userdId;
	}

}
