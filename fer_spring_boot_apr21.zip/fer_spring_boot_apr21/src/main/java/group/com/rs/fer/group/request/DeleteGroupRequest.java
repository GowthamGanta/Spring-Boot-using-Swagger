package com.rs.fer.group.request;

public class DeleteGroupRequest {
	
	private int groupId;

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
}
