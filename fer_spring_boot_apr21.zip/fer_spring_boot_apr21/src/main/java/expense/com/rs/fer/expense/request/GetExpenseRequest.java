package com.rs.fer.expense.request;

public class GetExpenseRequest {

	private int expenseId;

	public int getExpenseId() {
		return expenseId;
	}

	public void setExpenseId(int expenseId) {
		this.expenseId = expenseId;
	}

}
