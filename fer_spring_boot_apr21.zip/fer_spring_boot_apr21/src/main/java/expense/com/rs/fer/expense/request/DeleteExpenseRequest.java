/**
 * 
 */
package com.rs.fer.expense.request;

/**
 * @author Satish
 *
 */
public class DeleteExpenseRequest {

	
	private Integer expenseid;

	public Integer getExpenseid() {
		return expenseid;
	}

	public void setExpenseid(Integer expenseid) {
		this.expenseid = expenseid;
	}
	
	
	
}
