package com.rs.fer.expense.request;

public class GetExpensesRequest {

	private int userId;

	public int getUserId() {
		return userId;
	}
	
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
}
