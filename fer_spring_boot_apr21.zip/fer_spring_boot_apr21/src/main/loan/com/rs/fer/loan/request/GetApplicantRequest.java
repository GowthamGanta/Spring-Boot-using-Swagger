package com.rs.fer.loan.request;

public class GetApplicantRequest {

	private Integer ApplicantId;

	public Integer getApplicantId() {
		return ApplicantId;
	}

	public void setApplicantId(Integer applicantId) {
		ApplicantId = applicantId;
	}

}
