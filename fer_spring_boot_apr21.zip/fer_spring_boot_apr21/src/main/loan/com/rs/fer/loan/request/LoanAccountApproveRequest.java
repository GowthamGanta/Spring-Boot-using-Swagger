package com.rs.fer.loan.request;

public class LoanAccountApproveRequest {

	private int loanAccountId;

	public int getLoanAccountId() {
		return loanAccountId;
	}

	public void setLoanAccountId(int loanAccountId) {
		this.loanAccountId = loanAccountId;
	}

}
