package com.rs.fer.loan.request;

public class GetLoanAccountRequest {

	private int loanAccountId;

	public int getLoanAccountId() {
		return loanAccountId;
	}

	public void setLoanAccountId(int loanAccountId) {
		this.loanAccountId = loanAccountId;
	}
}
