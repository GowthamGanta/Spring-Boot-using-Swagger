package fer_spring_boot_apr21;

public class Test {

	public static void main(String[] args) {
		System.out.println("first git example");
		
		System.out.println("Second git Example...");
		System.out.println("Adding git hub ");
		
	}

}
